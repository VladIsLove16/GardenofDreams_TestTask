﻿using UnityEngine;

public class ItemGO : MonoBehaviour
{
    public ItemDetails ItemDetails;
}